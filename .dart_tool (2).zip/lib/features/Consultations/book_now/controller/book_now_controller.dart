import 'package:get/get.dart';

class BookNowController extends GetxController {}
