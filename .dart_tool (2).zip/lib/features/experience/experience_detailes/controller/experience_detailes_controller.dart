import 'package:get/get.dart';

class ExperienceDetailesController extends GetxController {}
