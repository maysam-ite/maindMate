enum StatusRequest {
  urlError,
  sucess,
  validationError,
  authErorr,
  validationErrorFormat,
  serverError,
  oldPasswordIsWrong,
  takenPhoneNumber,
  phoneNumberNotVerified,
  localError,
  wrongOTPCode,
  youAreBloced,
}
