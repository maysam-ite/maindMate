import 'package:get/get.dart';

class ExperienceOfOThersController extends GetxController {}
