import 'package:get/get.dart';

class BookAConsultationController extends GetxController {}
